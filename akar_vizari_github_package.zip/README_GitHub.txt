کویزی ویزاری — Made By Akar

چۆنیەتی بڵاوکردنەوە لە GitHub Pages:
1) لە GitHub repository ـێکی نوێ دروست بکە.
2) فایلەکە بە ناوی index.html باربکە لە ڕەگی repository ـەکە (Root).
3) بچۆ بۆ Settings > Pages.
4) لە Build and deployment، Source بکە بە Deploy from a branch.
5) Branch بکە main و Folder بکە / (root)، پاشان Save بکە.
6) چەند خولەکێک چاوەڕێ بکە؛ لینکی GitHub Pages لە هەمان بەشی Pages دەردەکەوێت.

تێبینی: هەموو کۆد و وێنەکان لەناو index.html ـدان؛ پێویست بە فایلێکی تر یان ئینتەرنێت بۆ کارکردنی کویز نییە.
